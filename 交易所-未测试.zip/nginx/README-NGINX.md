
# Nginx 配置使用说明

## 目录结构

- nginx/conf.d/*.conf → 每个子域配置
- nginx/ssl/ → SSL证书目录

## 快速使用流程

1️⃣ 安装 Nginx

```bash
sudo apt update
sudo apt install nginx
```

2️⃣ 配置域名 DNS → 指向服务器IP

```text
exchange.yourdomain.com → 服务器IP
admin.yourdomain.com    → 服务器IP
api.yourdomain.com      → 服务器IP
```

3️⃣ 申请 HTTPS 证书

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d exchange.yourdomain.com -d admin.yourdomain.com -d api.yourdomain.com
```

证书路径通常在：

```bash
/etc/letsencrypt/live/yourdomain.com/
```

把 nginx/conf.d/*.conf 里证书路径替换成实际路径：

```nginx
ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
```

4️⃣ 启动 Nginx

```bash
sudo systemctl restart nginx
sudo systemctl enable nginx
```

5️⃣ 浏览器访问

- https://exchange.yourdomain.com
- https://admin.yourdomain.com
- https://api.yourdomain.com

✅ 完成！
