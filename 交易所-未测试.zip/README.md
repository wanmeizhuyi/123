
# V13-FINANCIAL-CODE-DOCKER

一键Docker Compose部署包，包含：

- 前台 Vue3 Vite
- 后台 Vue3 Vite
- 后端 Node.js API（含特殊金融码功能）
- 数据库 MySQL

## 快速开始

```bash
docker-compose up -d
```

访问：

- http://localhost:8080 前台
- http://localhost:8081 后台
- http://localhost:3000 API
- MySQL 3306 端口



## 如何导入测试金融码

```bash
# 进入MySQL容器交互
docker exec -it v13_db mysql -u v13_user -p

# 手动执行 seed_financial_codes.sql 内容
# 或者用MySQL工具导入 database/seed_financial_codes.sql 文件
```

测试金融码列表：

- TESTCODE001 ～ TESTCODE010
