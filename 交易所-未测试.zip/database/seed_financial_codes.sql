
-- 批量插入 10 个测试金融码
INSERT INTO financial_codes (code, creator_admin_id, max_uses, used_count, is_active, expire_at)
VALUES
  ('TESTCODE001', 1, 10, 0, TRUE, '2030-12-31 23:59:59'),
  ('TESTCODE002', 1, 10, 0, TRUE, '2030-12-31 23:59:59'),
  ('TESTCODE003', 1, 10, 0, TRUE, '2030-12-31 23:59:59'),
  ('TESTCODE004', 1, 10, 0, TRUE, '2030-12-31 23:59:59'),
  ('TESTCODE005', 1, 10, 0, TRUE, '2030-12-31 23:59:59'),
  ('TESTCODE006', 1, 10, 0, TRUE, '2030-12-31 23:59:59'),
  ('TESTCODE007', 1, 10, 0, TRUE, '2030-12-31 23:59:59'),
  ('TESTCODE008', 1, 10, 0, TRUE, '2030-12-31 23:59:59'),
  ('TESTCODE009', 1, 10, 0, TRUE, '2030-12-31 23:59:59'),
  ('TESTCODE010', 1, 10, 0, TRUE, '2030-12-31 23:59:59');
